.. title: Listings Demo
.. slug: listings-demo
.. date: 2012-12-15 10:16:20 UTC-03:00
.. tags: 
.. link: 
.. description: 

Nikola intends to let you show code easily via listings:

.. listing:: hello.py python
