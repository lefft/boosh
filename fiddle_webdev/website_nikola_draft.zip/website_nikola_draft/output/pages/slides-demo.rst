.. title: Slides Demo
.. slug: slides-demo
.. date: 2012-12-27 10:16:20 UTC-03:00
.. tags: 
.. link: 
.. description: 

Nikola intends to let you do slideshows easily:

.. slides:: 
   
   /galleries/demo/tesla_conducts_lg.jpg
   /galleries/demo/tesla_lightning2_lg.jpg
   /galleries/demo/tesla4_lg.jpg
   /galleries/demo/tesla_lightning1_lg.jpg
   /galleries/demo/tesla_tower1_lg.jpg

